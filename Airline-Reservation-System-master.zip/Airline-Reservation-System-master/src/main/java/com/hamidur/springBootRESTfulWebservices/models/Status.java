package com.hamidur.springBootRESTfulWebservices.models;

public enum Status {
    ON_TIME, CANCELLED, ACTIVE
}
